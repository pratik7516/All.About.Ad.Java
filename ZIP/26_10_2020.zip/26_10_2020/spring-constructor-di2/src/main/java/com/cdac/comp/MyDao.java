package com.cdac.comp;

public class MyDao {
	
	public MyDao() {
		System.out.println("no arg MyDao() +++++++++++== ");
	}

	public void insert() {
		System.out.println("insert() called ======= ");
	}
}
