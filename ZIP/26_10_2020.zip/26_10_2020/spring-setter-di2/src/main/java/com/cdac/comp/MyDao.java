package com.cdac.comp;

public class MyDao {
	public void insert() {
		System.out.println("insert() called ======= ");
	}
}
