package com.cdac.comp;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class MyColl {
	private List<String> myList;
	private Set<String> mySet;
	private Map<String, Object> myMap;
	private Properties myProperties;
	private String[] myArr;
	public MyColl() {
		super();
		// TODO Auto-generated constructor stub
	}
	public List<String> getMyList() {
		return myList;
	}
	public void setMyList(List<String> myList) {
		this.myList = myList;
	}
	public Set<String> getMySet() {
		return mySet;
	}
	public void setMySet(Set<String> mySet) {
		this.mySet = mySet;
	}
	public Map<String, Object> getMyMap() {
		return myMap;
	}
	public void setMyMap(Map<String, Object> myMap) {
		this.myMap = myMap;
	}
	public Properties getMyProperties() {
		return myProperties;
	}
	public void setMyProperties(Properties myProperties) {
		this.myProperties = myProperties;
	}
	public String[] getMyArr() {
		return myArr;
	}
	public void setMyArr(String[] myArr) {
		this.myArr = myArr;
	}
	
	
	
}
