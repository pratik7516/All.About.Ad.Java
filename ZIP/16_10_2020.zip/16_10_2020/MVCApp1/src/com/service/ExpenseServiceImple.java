package com.service;

import java.util.ArrayList;

import com.dto.Expense;

public class ExpenseServiceImple implements ExpenseService {

	@Override
	public int addExpense(Expense expense) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int modifyExpense(Expense expense) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int removeExpense(int expenseId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public ArrayList<Expense> expenseList(int userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Expense findExpense(int expenseId) {
		// TODO Auto-generated method stub
		return null;
	}

}
