package com.cdac.comp;

public abstract class Shape {
	private float area;

	public Shape() {
		super();
		// TODO Auto-generated constructor stub
	}

	public float getArea() {
		return area;
	}

	public void setArea(float area) {
		this.area = area;
	}
	
}
