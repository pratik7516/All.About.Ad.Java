package com.cdac.comp;

public class Rectangle extends Shape {

	private float length;
	private float breadth;
	public Rectangle() {
		super();
		// TODO Auto-generated constructor stub
	}
	public float getLength() {
		return length;
	}
	public void setLength(float length) {
		this.length = length;
	}
	public float getBreadth() {
		return breadth;
	}
	public void setBreadth(float breadth) {
		this.breadth = breadth;
	}
	
}
