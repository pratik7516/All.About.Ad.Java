package com.cdac.comp;

public class MyDao {
	
	public MyDao() {
		System.out.println("constructor called +++++++++++++++ ");
	}

	public void insert() {
		System.out.println("insert() called ======= ");
	}
}
