package com.cdac.comp;

public class MyBean {
	private String msg;

	public MyBean() {
	
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	
}
